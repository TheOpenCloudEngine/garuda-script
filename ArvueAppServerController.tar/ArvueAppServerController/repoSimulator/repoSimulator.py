#Copyright Jon Berg , turtlemeat.com

import string,cgi,time, sys
import os
from os import curdir, sep
from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
#import pri

repoDir = ""
port = 4444

class MyHandler(BaseHTTPRequestHandler):

    def do_GET(self):
        
        print self.path

        # Send list
        if self.path == "/list":
            contents = ""
            try:
                dirList = os.listdir(repoDir)
                for app in dirList:
                    try:
                        appDirList = os.listdir(repoDir + app)
                        if len(appDirList) > 0:
                            appFileName = appDirList[0]
                            contents += app + " " + appFileName + "\n"
                    except:
                        pass
                self.send_response(200)
                self.send_header('Content-type','text/plain')
                self.end_headers()
                self.wfile.write(contents)
            except:
                pass
            return

        # Send file
        if self.path.endswith(".jar"):
            print "filepath:", repoDir + self.path
            print "filename:", self.path.split("/")[-1]
            try:
                contents = open(repoDir + self.path).read()
                self.send_response(200)
                self.send_header('Content-disposition','attachment; filename=' + self.path.split("/")[-1])
                self.end_headers()
                self.wfile.write(contents)
            except:
                self.send_error(404,'File Not Found: %s' % self.path) 
            return

        # Redirect
        path = self.path
        if path.startswith("/"):
            path = path[1:]
        path = repoDir + path
        print "received request for:", path
        try:
            dirList = os.listdir(path)
            if len(dirList) <= 0:
                contents = ""
            else:
                contents = open(path + "/" +  dirList[0]).read()
            
            print "returning:", dirList[0]
            self.send_response(303)
            #self.send_header('Content-type','application/jar')
            #self.send_header('Content-disposition','attachment; filename=' + dirList[0])
            self.send_header('Location', self.path + "/" + dirList[0])
            self.end_headers()
            self.wfile.write(contents)
            return
                
        except:
            self.send_error(404,'File Not Found: %s' % self.path)
            #pass

if __name__ == '__main__':

    if len(sys.argv) != 3:
        print "Usage: ", sys.argv[0], "<repo directory path> <port>"
        exit(1)
    else:
        try:
            repoDir = sys.argv[1]
            port = int(sys.argv[2])
        except:
            pass
    
    if not repoDir.endswith("/"):
        repoDir += "/"

    print "Starting Repo Simulator"
    print "port:", port
    print "dir:", repoDir

    try:
        server = HTTPServer(('', port), MyHandler)
        print 'started httpserver...'
        server.serve_forever()
    except KeyboardInterrupt:
        print '^C received, shutting down server'
        server.socket.close()


