'''
Created on Feb 9, 2011

@author: nsnellma
'''

import re

class ShellInfo(object):
    def getMem(self):
        f = open('/proc/meminfo', 'r')

        memtotal = int(f.readline().split(' ')[-2])
        memfree = int(f.readline().split(' ')[-2])
        buffers = int(f.readline().split(' ')[-2])
        cached = int(f.readline().split(' ')[-2])
        
        f.close()
        
        return (memtotal, memfree + buffers + cached)


    def getCPU(self):
            f = open('/proc/cpuinfo', 'r')
            cpu_count = len(re.findall('^processor', f.read(), re.MULTILINE))
            f.close()
    
            f = open('/proc/loadavg', 'r')
            data = f.read().split(' ')
            f.close()
            del data[3:]
    
            return [float(value) / cpu_count for value in data]
