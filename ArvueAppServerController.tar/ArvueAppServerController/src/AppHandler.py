'''
Created on Feb 9, 2011

@author: nsnellma
'''

import subprocess, urllib, thread, urllib2, traceback
import time, math, re, sys, hmac, httplib, sha, base64
import os

def appStartupMonitor(appName, appFileName, appDir):
    
    felixPort = 8000 # TODO: check this somehow
    loaded = False
    
    print "appStartupMonitor running 8000"
    
    # Load the app
    for i in range(0, 100):
        try:
    	    print "appStartupMonitor running 8000"
            urllib2.urlopen("http://localhost:" + str(felixPort) + "/" + appName)
            loaded = True
            break
        except:
            #print "failed"
            time.sleep(0.5)
            pass
    
    if loaded:
        print "added " + str(appName) + " to deployed"
        appList = open(appDir + "deployed", 'a')
        appList.write(appName + " " + appFileName + " " + str(int(math.floor(time.time()))) + "\n")
        
    print "appStartupMonitor done"
    
class AppHandler(object):
    '''
    classdocs
    '''

    def __init__(self, appDir, appRepoUrl, awsCredentials):
        self.appDir = appDir
        self.appRepoUrl = appRepoUrl
        self.awsCredentials = awsCredentials
        if self.appRepoUrl.endswith("/"):
            self.appRepoUrl = self.appRepoUrl[:-1]

        if not os.path.exists(self.appDir):
            os.makedirs(self.appDir)
        # Create deployed apps list file
        #subprocess.Popen(["rm", self.appDir + "deployed"])
        subprocess.Popen(["touch", self.appDir + "deployed"])
        
    def setRepoUrl(self, url):
        self.appRepoUrl = url
    
    def deployApp(self, appName, version):

        # Check if app exists
        bundleName = None
        try: 
            bundleName = self._appExists(appName)
        except:
            pass

        print "result Bundle : "
        print bundleName

        if not bundleName:
            return '{"result":"failed", "message": "' + appName + ' does not exist"}'
        
        # Check if app is already deployed
        appDeployed = None
        try:
            appDeployed = self._appDeployed(appName)
        except:
            pass
        if appDeployed:
            return '{"result":"failed", "message": "' + appName + ' is already deployed"}'
        
        # Get bundle name
        #bundleName = self._getBundleName(appName)
        #print "Bundle name for " + appName + " is " + bundleName
        
        # Deploy if app exists
        appDeployed = None
        try:
            appDeployed = self._deployApp(appName, bundleName, version)
        except:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            traceback.print_exc(file=sys.stdout)
            print "*** print_tb:"
            traceback.print_tb(exc_traceback, limit=1, file=sys.stdout)
            print "*** print_exception:"
            traceback.print_exception(exc_type, exc_value, exc_traceback,
                              limit=2, file=sys.stdout)
            pass
        print "baa: ", appDeployed
        if not appDeployed:
            return '{"result":"failed", "message": "deployment failed"}'        
        return '{"result":"success", "message": "deployed ' + appName + '"}'
    
    def removeApp(self, appName):

        # Check if app is deployed
        appDeployed = None
        try:
            appDeployed = self._appDeployed(appName)
        except:
            raise
        if not appDeployed:
            return '{"result":"failed", "message": "' + appName + ' is not deployed"}'
                
        # Remove app
        appRemoved = None
        try:
            appRemoved = self._removeApp(appName)
        except:
            raise
        if not appRemoved:
            return '{"result":"failed"}'
        return '{"result":"success", "message": "removed ' + appName + '"}'    

    def _appExists(self, appName):
        print "Checking if " + appName + " exists in repository..."
        
        '''
        # Remove previous list
        subprocess.Popen(["rm", self.appDir + "repolist"])
        
        # Download list of apps
        d = Downloader()
        d.downloadFile(self.appRepoUrl + "/list", self.appDir, "repolist")

        # Check list for appName
        appExists = False
        list = open(self.appDir + "repolist").readlines()
        for app in list:
            if app.split()[0] == appName:
                appExists = True
                break
        
        if appExists:
            print appName + " exists!"
        return appExists
        '''
        d = Downloader()
        bucketContentsXML = d.downloadURL(self.appRepoUrl)
        
        # Find all bundles by checking for <Key>bundlename</Key> tags
        match = re.findall("(<Key>)([^(<)]+)", bucketContentsXML)
        for key in match:
            bundleName = key[1]
            print "bundleName : " + bundleName
        
            # Match the bundle name using the naming convention
            bundleAppName = bundleName

            print "bundleAppName : " + bundleAppName
            print "appName" + appName
            
            if bundleAppName == appName + ".jar":
                return bundleName
            
        return False
        

    def _getBundleName(self, appName):
        
        # Load list
        
        """apps = open(self.appDir + "repolist").readlines()
        for line in apps:
            match = re.match('([^\s]*)(\s)([^\s]*)\n', line)
            if match:
                if match.group(1) == appName:
                    return match.group(3)
        return None
        """
        
        # This should be OK according to the naming convention
        return appName + ".jar"
    
    def _appDeployed(self, appName):
        try:
        
            # Get the list of deployed apps
            deployedApps = open(self.appDir + "deployed", 'r').readlines()
            
            for appLine in deployedApps:
                if appLine.split()[0] == appName:
                    return True
            
            return False
        except:
            raise
    
    def _deployApp(self, appName, bundleName, version):
        
        # TODO: implement versioning at some point
        
        # Check if the repository is in S3
        try:
            S3repo = False
            if self.appRepoUrl.count("s3.amazonaws.com") > 0:
                S3repo = True
            
            result = False
            if S3repo:
                print "Trying to download app from S3 *fingers crossed*"

                match = re.match("(\S+)(\.s3\.amazonaws\.com)", self.appRepoUrl)
                bucketName = match.group(1)
                d = Downloader()
                result = d.downloadS3File(self.appRepoUrl, bucketName, bundleName, self.appDir, self.awsCredentials.getAccessKey(), self.awsCredentials.getSecretKey())
                print "s3 results: ", result
            else:
                d = Downloader()          
                result = d.downloadFile(self.appRepoUrl + "/" + bundleName, self.appDir)
                print "other results: ", result
            
            # Start an appStartupMonitor
            if result == True:
                thread.start_new_thread(appStartupMonitor, (appName, bundleName, self.appDir, ))
        
            return result
        except:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            traceback.print_exc(file=sys.stdout)
            print "*** print_tb:"
            traceback.print_tb(exc_traceback, limit=1, file=sys.stdout)
            print "*** print_exception:"
            traceback.print_exception(exc_type, exc_value, exc_traceback,
                              limit=2, file=sys.stdout)
    
    def getDeployedApps(self):
        try:
        
            # Get the list of deployed apps
            try:
                deployedAppsList = open(self.appDir + "deployed", 'r').readlines()
            except:
                return None
            
            deployedApps = []
            for appLine in deployedAppsList:
                if len(appLine) <= 1:
                    continue
                app = appLine.split()[0]
                appFileName = appLine.split()[1]
                appDeployTime = int(math.floor(time.time())) - int(appLine.split()[2])
    
                deployedApps.append([app, appFileName, appDeployTime])
            
            print deployedApps
            return deployedApps
        except:
            raise
        
    def _removeApp(self, appName):
        try:
            stderr = "error"
          
            # Get the list of deployed apps  
            deployedApps = open(self.appDir + "deployed", 'r').readlines()
            
            # Write a new list
            newDeployedList = open(self.appDir + "deployed.new", 'w')
            remFileName = ""
            for appLine in deployedApps:
                app = appLine.split()[0]
                appFileName = appLine.split()[1]
                appDeployTime = appLine.split()[2]
                if appDeployTime.endswith("\n"):
                    appDeployTime = appDeployTime[:-1]
                if app == appName:
                    remFileName = appFileName
                else:
                    newDeployedList.write(app + " " + appFileName + " " + appDeployTime +"\n")
            newDeployedList.close()
            
            # Remove the app file
            subprocess.Popen(["rm", self.appDir + remFileName])
            
            # Swap the files
            subprocess.Popen(["mv", self.appDir + "deployed.new", self.appDir + "deployed"])
            
            return True
        except:
            raise
        
class Downloader(object):
    def __init__(self):
        pass
    
    def downloadURL(self, url):
        if not url.startswith("http://"):
            url = "http://" + url
        file, headers = urllib.urlretrieve(url)
        input = open(file).read()
        return input
    
    def downloadFile(self, url, dir, filename=None):
        if not url.startswith("http://"):
            url = "http://" + url
        print "downloading", url, "to", dir,
        if filename is not None:
            print filename
        else:
            print
        if not dir.endswith("/"):
            dir += "/"
        try:
            file, headers = urllib.urlretrieve(url)
            if filename is None:
                filename = url.split("/")[-1]
                try:
                    content_disp = headers.get("Content-disposition")
                except:
                    pass
            input = open(file)
            output = open(dir + filename, 'wb')
            output.write(input.read())
            output.close()
        except:
            return False
        return True
    
    def signature(self, date, bucket, bundle, AWSAccessKey, AWSSecretKey):
        
        descString = "GET\n\n\n" + str(date) + "\n/" + bucket + "/" + bundle
        h = hmac.new(AWSSecretKey, unicode(descString, "utf-8"), sha)
        #sig = urllib.quote_plus(base64.encodestring(h.digest()).strip())
        sig = base64.encodestring(h.digest().strip())
        return sig

    def dateString(self):
        seconds = int(time.time() + 60)
        expires = time.gmtime(seconds)
        date = time.strftime("%a, %d %b %Y %H:%M:%S GMT", expires)
        return date
    
    def downloadS3File(self, host, bucket, bundle, dir, AWSAccessKey, AWSSecretKey):
        date = self.dateString()
        sig = self.signature(date, bucket, bundle, AWSAccessKey, AWSSecretKey)
        
        headers = {"Host": host, "Date": date, "Authorization": "AWS " + AWSAccessKey + ":" + sig}
        print "Downloading to: " + dir
        print "GET /" + bundle + " HTTP/1.1"
        print "Host: " + host
        print "Date: " + date
        print "Authorization: AWS " + AWSAccessKey + ":" + sig
        print "bundle " + bundle
            
        conn = httplib.HTTPConnection(host)
        conn.request("GET", "/" + bundle, None, headers)
        response = conn.getresponse()
        print "response: ", response
        print "step 1"

        if str(response.status) == "200":
            print "step 2"
            output = open(dir + bundle, 'wb')
            output.write(response.read())
            output.close()
            print "Downloaded " + bundle
            return True
        print "step 6"
        return None
        
