'''
Created on Feb 9, 2011

@author: nsnellma
'''

import sys, base64, re, traceback
import simplejson
from ShellInfo import ShellInfo
from AppHandler import AppHandler
from AppHandler import Downloader
from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer

class AWSCredentials(object):
    
    def __init__(self):
        self.accessKey = ""
        self.secretKey = ""
    
    def setAccessKey(self, key):
        self.accessKey = key
    def setSecretKey(self, key):
        self.secretKey = key
    def getAccessKey(self):
        return self.accessKey
    def getSecretKey(self):
        return self.secretKey

# Globals
global shellInfo
global appHandler
global authenticate
global port
global appDir
global appRepoUrl
global syslogServerPort
global awsCredentials

def getResponseTimes():
    global syslogServerPort
    d = Downloader()
    result = None
    try:
        statusMsg = d.downloadURL("http://127.0.0.1:" + str(syslogServerPort) + "/status")
        result = simplejson.loads(statusMsg)
    except:
        pass 
    if result:
        return result
    else:
        return None

def getStatusJSONString():
    cpu = shellInfo.getCPU()
    s = "{"
    s += '"repoUrl":"' + appRepoUrl + '",'
    s += '"cpu1min":"' + str(cpu[0]) + '",'
    s += '"cpu5min":"' + str(cpu[1]) + '",'
    s += '"cpu10min":"' + str(cpu[2]) + '",'
    s += '"memTotal":"' + str(shellInfo.getMem()[0]) + '",'
    s += '"memFree":"' + str(shellInfo.getMem()[1]) + '",'
    
    responseTimes = getResponseTimes()
    if responseTimes is not None:
        try:
            responseTimes = responseTimes['apps']
        except:
            pass
        
    s += '"deployedApps":['
    deployedApps = appHandler.getDeployedApps()
    if deployedApps != None:
        for app in appHandler.getDeployedApps():
            s += "{"
            s += '"bundleName":"' + str(app[1]) + '",'
            s += '"appName":"' + str(app[0]) + '",'
            s += '"deployTimeSeconds":"' + str(app[2]) + '",'
            
            # Write app status
            avgResponseTime = 0
            duration = 0
            requests = 0
            try:
                if responseTimes[str(app[0])]:
                    appStatus = responseTimes[str(app[0])]
                    # Add the app status to the json string but first remove the {} and replace ' with "
                    avgResponseTime = float(appStatus['avgResponseTime'])
                    duration = float(appStatus['duration'])
                    requests = float(appStatus['requests'])
            except:
                pass
            s += '"avgResponseTime":"' + str(avgResponseTime) + '",'
            s += '"duration":"' + str(duration) + '",'
            s += '"requests":"' + str(requests) + '"'
            s += "},"
    if s.endswith(","):
        s = s[:-1]
        
    s += "]}"
    return s

class Request(object):
    def __init__(self):
        self.appName = None
        self.version = None
        self.action = None
        self.value = None
    
    def __repr__(self):
        return str(self.appName) + " " + str(self.version) + " " + str(self.action)
        

def parseRequest(path):
    ret = Request()
    
    # Command: app [deploy|remove]
    match = re.match('(\/)([^(\/)]+)(\/)([^(\/)]+)\Z', path)
    if match:
        ret.appName = match.group(2)
        ret.action = match.group(4)
    
    # Command: app version [deploy|remove]
    match = re.match('(\/)([^(\/)]*)(\/)([^(\/)]*)(\/)([^(\/)]*)\Z', path)
    if match:
        ret.appName = match.group(2)
        ret.version = match.group(4)
        ret.action = match.group(6)
        
    # Command: status
    match = re.match('(\/)*(status)', path)
    if match:
        ret.action = "status"
    
    # Command: update repo url
    match = re.match('(\/)*(updateRepoUrl)(\/)([^(\/)]*)', path)
    if match:
        ret.action = "updateRepoUrl"
        #ret.value = match.group(4)
        ret.value = path[15:]
        
    # Command: update AWS secret key
    match = re.match('(\/)*(updateSecretKey)(\/)([\S+)]*)', path)
    if match:
        ret.action = "updateSecretKey"
        ret.value = match.group(4)

    # Command: update AWS access key
    match = re.match('(\/)*(updateAccessKey)(\/)([\S+]*)', path)
    if match:
        ret.action = "updateAccessKey"
        ret.value = match.group(4)
    # Command: update arvuemasterip
    match = re.match('(\/)*(updateMasterIp)(\/)([\S+]*)', path)
    if match:
        ret.action = "updateMasterIp"
        ret.value = match.group(4)
        
    return ret

class RequestHandler(BaseHTTPRequestHandler):

    def do_POST(self):
        # globals
        global authenticate
        global appRepoUrl
        global awsCredentials
        
        # Authenticate
        if authenticate:
            bauth = None
            try:
                auth = self.headers.get("Authorization")
                bauth = base64.b64decode(auth)
            except:
                auth = False
                # TODO: authentication string
            if bauth != "someauthenticationstring":
                self.send_response(401)
                self.send_header("Content-type", "text/html")
                self.wfile.write("Authorization failed")
                print "Authorization failed"
                return
        
        path = self.requestline.split()[1]
        print self.requestline
        
        # Parse request
        request = parseRequest(path)
        
        response = ""
        
	print "action : " + request.action

        # Deploy app
        if request.action == "deploy":
            try:
                response = appHandler.deployApp(request.appName, request.version)
            except:
                print "Error: Could not deploy app"
                traceback.print_exc(file=sys.stdout)
                response = '{"result":"failed", "message": "could not deploy app"}'

        # Remove app
        if request.action == "remove":
            try:
                response = appHandler.removeApp(request.appName)
            except:
                print "Error: Could not remove app"
                traceback.print_exc(file=sys.stdout)
                response = '{"result":"failed", "message": "could not remove app"}'
            
        # Status        
        if request.action == "status":
            response = getStatusJSONString()
        
        # Update repo url
        if request.action == "updateRepoUrl":
            appRepoUrl = request.value
            appHandler.setRepoUrl(appRepoUrl)
            print "Updated appRepoUrl:", appRepoUrl
            response = '{"result":"success", "repoUrl":"' + appRepoUrl + '"}'
            
        if request.action == "updateAccessKey":
            awsCredentials.setAccessKey(request.value)
            print "Updated AWS Access Key:", awsCredentials.getAccessKey()
            response = '{"result":"success", "accessKey":"' + awsCredentials.getAccessKey() + '"}'
            
        if request.action == "updateSecretKey":
            awsCredentials.setSecretKey(request.value)
            print "Updated AWS Secret Key:", awsCredentials.getSecretKey()
            response = '{"result":"success", "secretKey":"' + awsCredentials.getSecretKey() + '"}'
            
        if request.action == "updateMasterIp":
            f = open('/tmp/arvuemastername', 'w')
            print >> f, request.value
            f.close()
            response ='{"result":"success", "MasterIp":"'+request.value+ '"}'
            
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(response)

if __name__ == '__main__':

    if len(sys.argv) == 2 and sys.argv[1] == "--help":
        print "Usage:", sys.argv[0], " [OPTIONS]"
        print "\n Options:"
        print "\t-d\tApp directory path"
        print "\t-p\tListen port"
        print "\t-r\tApp repo url"
        exit(1)

    # Default options
    global authenticate
    global port
    global appDir
    global appRepoUrl
    global syslogServerPort
    global awsCredentials
    port = 5555
    appDir = "/tmp/arvue"
    #appRepoUrl = "localhost:4444"
    appRepoUrl = "192.168.50.3:8080/RepositoryService/app-repo-dev"
    authenticate = False
    syslogServerPort = 2323
    awsCredentials = AWSCredentials()

    # Read conf
    confFile = "arvuemon.conf"
    for i in range(0, len(sys.argv)):
        if sys.argv[i] == "-f":
            try:
                confFile = sys.argv[i+1]
            except:
                pass
    print "reading config: " + confFile

    try:
        confFileContents = open(confFile).readlines()
        for line in confFileContents:
            if line.startswith("port"):
                try:
                    port = int(line.split("=")[1])
                except:
                    pass
            if line.startswith("appdir"):
                try:
                    appDir = line.split("=")[1]
                    if appDir.endswith("\n"):
                        appDir = appDir[:-1]
                except:
                    pass
            if line.startswith("apprepourl"):
                try:
                    appRepoUrl = line.split("=")[1]
                    if appRepoUrl.endswith("\n"):
                        appRepoUrl = appRepoUrl[:-1]
                except:
                    pass
            if line.startswith("authenticate"):
                try:
                    if line.split("=")[1].lower() == "true":
                        authenticate = True
                except:
                    pass
            if line.startswith("syslogserverport"):
                try:
                    syslogServerPort = line.split("=")[1]
                    if syslogServerPort.endswith("\n"):
                        syslogServerPort = syslogServerPort[:-1]
                except:
                    pass
    except:
        print "couldn't read config, using default values"
    
    # Parse command line arguments
    for i in range(0, len(sys.argv)):
        if sys.argv[i] == "-d":
            try:
                appDir = sys.argv[i+1]
            except:
                pass
        if sys.argv[i] == "-p":
            try:
                port = int(sys.argv[i+1])
            except:
                pass
        if sys.argv[i] == "-r":
            try:
                appRepoUrl = sys.argv[i+1]
            except:
                pass
        if sys.argv[i] == "-s":
            try:
                syslogServerPort = int(sys.argv[i+1])
            except:
                pass

    # Fix urls
    if not appDir.endswith("/"):
            appDir += "/"
            
    print "port:", port
    print "appdir:", appDir
    print "apprepourl:", appRepoUrl
    print "syslogServerPort:", syslogServerPort
    print "authentication required:", authenticate
    
    # TODO: check if app directory exists
    # TODO: report if repo can't be contacted
    
    # Create new globals
    shellInfo = ShellInfo()
    appHandler = AppHandler(appDir, appRepoUrl, awsCredentials)

    # Start server
    try:
        server = HTTPServer(('', port), RequestHandler)
        print "Started AppServerController"
        server.serve_forever()
    except KeyboardInterrupt:
        server.socket.close()
        
        
        
